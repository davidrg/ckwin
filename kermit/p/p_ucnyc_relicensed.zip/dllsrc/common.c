/*
 * Copyright 1995 Jyrki Salmi, Online Solutions Oy (www.online.fi)
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* Routines common for all protocols and both transfer directions */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "typedefs.h"
#include "common.h"
#include "defs.h"
void msg(U32, U8 *, ...);
#include "dev.h"
#include "global.h"
#include "main.h"

void cancel(void) {

  U32 i = 0;
  char caninstr[] = { 24,24,24,24,24,24,24,24,8,8,8,8,8,8,8,8,8,8,0 };

  dev_purge_outbuf();
  while (caninstr[i])
    dev_putch_buf(caninstr[i++]);
  dev_flush_outbuf();
}

void carrier_lost(void) {
  
  if (p_cfg->status_func(PS_CARRIER_LOST))
    user_aborted();
  aborted = A_CARRIER_LOST;
  longjmp(p_jmp_buf, 1);
}

U32 user_aborted_visited;

void user_aborted(void) {

  if (user_aborted_visited)
    return;
  else
    user_aborted_visited = 1;

  aborted = A_LOCAL;
  if (dev_ready)
    cancel();
  DosSleep(2000);		/* Let's give remote a few secs */
				/* to interpret our cancelation */
  longjmp(p_jmp_buf, 1);
}

void server_connect(void) {

  U32 cnt = 0;

  do {
    if (p_cfg->status_func(PS_SERVER_WAITING, cnt++))
      user_aborted();
  } while (!dev_connect());
}

/*
 * Copyright 1995 Jyrki Salmi, Online Solutions Oy (www.online.fi)
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */


/*
   Routines that load P.DLL and get the address of p_tranfer() entry
   function.
*/

#include <stdio.h>
#define INCL_DOSMODULEMGR
#define INCL_DOSPROCESS
#include <os2.h>
#include "typedefs.h"
#include "common.h"
#include "p.h"
#include "p_dll.h"
#include "error.h"
#include "modules.h"

static HMODULE dll_handle;
U32 (* _System p_transfer)(P_CFG *) = NULL;

char *get_exe_path(void) {

  PTIB tib;
  PPIB pib;

  DosGetInfoBlocks(&tib, &pib);	/* rc is always 0, no need to check */
  return(pib->pib_pchcmd);
}

void load_p_dll(void) {

  APIRET rc;
  U8 *exe_path;
  U8 path[256];

  rc = DosLoadModule(NULL, 0L, "P", &dll_handle);
  if (rc) {
    /* P.DLL was not found in directory specified with LIBPATH, let's look */
    /* up for it from the directory where P.EXE was ran from. */
    exe_path = get_exe_path();
    sprintf(path, "%.*sP.DLL", (int)get_dir_len(exe_path), exe_path);
    rc = DosLoadModule(NULL, 0L, path, &dll_handle);
    if (rc)
      os2_error(P_ERROR_DOSLOADMODULE, rc, MODULE_P_DLL, __LINE__, path);
  }
  /* Query the address of p_transfer() entry function */
  rc = DosQueryProcAddr(dll_handle,
			0,
			"p_transfer",
			(PFN *)&p_transfer);
  if (rc)
    os2_error(P_ERROR_DOSQUERYPROCADDR, rc,
	    MODULE_P_DLL, __LINE__,
	    "p_transfer");
}

void unload_p_dll(void) {

  APIRET rc;

  rc = DosFreeModule(dll_handle);
  if (rc)
    os2_error(P_ERROR_DOSFREEMODULE, rc,
	    MODULE_P_DLL, __LINE__,
	    "P");
}

/*
 * Copyright 1995 Jyrki Salmi, Online Solutions Oy (www.online.fi)
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */


U8 *usage =
"P version 2.05.  Copyright (c) 1994 by Jyrki Salmi.  All rights reserved.\n\n"
"Usage: %s [<option> ...] [-] [<file> | <@listfile> ...]\n\n"
"Where <option> can be one of these:\n"
"\n"
" -type {async | pipe | socket}\n"
" -device <name | path>\n"
" -host <address>\n"
" -port <port>\n"
" -server\n"
" -wait <seconds>\n"
" -share\n"
" -handle <handle>\n"
" -loose\n"
" -telnet\n"
" -receive\n"
" -send\n"
" -protocol {xmodem | ymodem | ymodem-g | zmodem}\n"
" -escape {controls | minimal}\n"
" -alternative\n"
" -kilo\n"
" -window <bytes>\n"
" -automatic\n"
" -serial\n"
" -attention <string>\n"
" -commbufs <bytes>\n"
" -comminbuf <bytes>\n"
" -commoutbuf <bytes>\n"
" -filebuf <bytes>\n"
" -speed <bps>\n"
" -mileage\n"
" -options\n"
" -headers\n"
" -frameends\n"
" -note <text>\n"
" -quiet\n"
" -priority <class> <delta>\n"
" -dszlog <path>\n"
" -pause\n"
" -directory <directory>\n"
" -paths\n"
" -create\n"
" -clean\n"
" -touch\n"
" -recursive\n"
" -text\n"
" -resume\n"
" -existing\n"
" -update\n"
" -append\n"
" -replace\n"
" -newer\n"
" -different\n"
" -protect\n"
" -rename\n"
"\n"
"End of usage, see P.DOC for more information.\n"
;

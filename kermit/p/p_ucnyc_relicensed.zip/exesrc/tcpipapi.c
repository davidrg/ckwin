/*
 * Copyright 1995 Jyrki Salmi, Online Solutions Oy (www.online.fi)
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */


/*
   Routines that load TCP/IP's socket library and get the address of
   psock_errno() entry function that is used get information about the
   error occurred in the TCP/IP API.

   Reasons for not using an import library:

   (1) People without TCP/IP can still use the program. No attempt to use 
       the TCP/IP API is made if the device type is something else than
       socket.

   (2) Program can be recompiled without the TCP/IP programmers toolkit.
*/

#include <stdio.h>
#define INCL_DOSMODULEMGR
#include <os2.h>
#include "p.h"
#include "tcpipapi.h"
#include "error.h"
#include "modules.h"

static HMODULE dll_handle;
void (* _System psock_errno)(U8 *) = NULL;

void load_tcpip(void) {

  APIRET rc;

  rc = DosLoadModule(NULL, 0L, "SO32DLL", &dll_handle);
  if (rc)
    os2_error(P_ERROR_DOSLOADMODULE, rc,
	      MODULE_TCPIP, __LINE__,
	      "SO32DLL");

  /* Query the address of psock_errno() entry function */

  rc = DosQueryProcAddr(dll_handle,
			0,
			"PSOCK_ERRNO",
			(PFN *)&psock_errno);
  if (rc)
    os2_error(P_ERROR_DOSQUERYPROCADDR, rc,
	    MODULE_TCPIP, __LINE__,
	    "PSOCK_ERRNO");
}

void unload_tcpip(void) {

  APIRET rc;

  rc = DosFreeModule(dll_handle);
  if (rc)
    os2_error(P_ERROR_DOSFREEMODULE, rc,
	    MODULE_TCPIP, __LINE__,
	    "SO32DLL");
}

/*
 * Copyright 1995 Jyrki Salmi, Online Solutions Oy (www.online.fi)
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */


/*
   A bit cleaner directory handling routines than the OS/2's DosFindFirst and
   DosFindNext. Note that dir_find_close() should be called when done with
   the directory listing.
*/

#include <stdio.h>
#define INCL_DOSFILEMGR
#include <os2.h>
#include <string.h>
#include <stdlib.h>
#include "typedefs.h"
#include "dir.h"

/* Finds a first file */

U32 dir_find_first(U8 *mask,
		   U32 attribute,
		   DIR_ENTRY *dir_entry) {

  U32 find_count = 1;
  APIRET rc;

  if ((dir_entry->find_buf = malloc(sizeof(FILEFINDBUF3))) == NULL) {
    fprintf(stderr, "Failed to allocate memory\n");
    exit(1);
  }
  dir_entry->handle = HDIR_CREATE; /* HDIR_SYSTEM; */
  rc = DosFindFirst(mask,
		    &dir_entry->handle,
		    attribute,
		    dir_entry->find_buf,
		    sizeof(FILEFINDBUF3),
		    &find_count,
		    FIL_STANDARD);
  dir_entry->name = ((FILEFINDBUF3 *)dir_entry->find_buf)->achName;
  dir_entry->size = (U32 *)&((FILEFINDBUF3 *)dir_entry->find_buf)->cbFile;
  dir_entry->date = (U16 *)&((FILEFINDBUF3 *)dir_entry->find_buf)->fdateLastWrite;
  dir_entry->time = (U16 *)&((FILEFINDBUF3 *)dir_entry->find_buf)->ftimeLastWrite;
  dir_entry->attribute = &((FILEFINDBUF3 *)dir_entry->find_buf)->attrFile;
  return(rc);
}

/* Finds the next file */

U32 dir_find_next(DIR_ENTRY *dir_entry) {

  U32 find_count = 1;
  APIRET rc;

  rc = DosFindNext(dir_entry->handle,
		   dir_entry->find_buf,
		   sizeof(FILEFINDBUF3),
		   &find_count);
  dir_entry->name = ((FILEFINDBUF3 *)dir_entry->find_buf)->achName;
  dir_entry->size = (U32 *)&((FILEFINDBUF3 *)dir_entry->find_buf)->cbFile;
  dir_entry->date = (U16 *)&((FILEFINDBUF3 *)dir_entry->find_buf)->fdateLastWrite;
  dir_entry->time = (U16 *)&((FILEFINDBUF3 *)dir_entry->find_buf)->ftimeLastWrite;
  dir_entry->attribute = &((FILEFINDBUF3 *)dir_entry->find_buf)->attrFile;
  return(rc);
}

/* Ends the directory handling started by dir_find_first() */

U32 dir_find_close(DIR_ENTRY *dir_entry) {

  APIRET rc;

  rc = DosFindClose(dir_entry->handle);
  return(rc);
}
